const POPULAR_MOVIES_ROUTE = '/popular-movie';
const TOP_RATED_ROUTE = '/top-rated-movie';
const MOVIE_DETAIL_ROUTE = '/detail';
const SEARCH_ROUTE = '/search';
const ABOUT_ROUTE = '/about';
